/*
 * nIP-C.c
 *
 * Created: 17/07/2019 6:28:29:PM
 * Author : Usuario1
 */ 

//Features: No Delayed ACKs, No Nagle Algorithm, No Urgent mode, No PSH flag, No Sliding Window, No Congestion Window 


#include <avr/io.h>
#include <avr/delay.h>
#include "net.h"
#include "mynet.h"
#include "nipconfig.h"
#include "drivers/enc28j60.h"

// set output to VCC, red LED off
#define LEDOFF PORTB|=(1<<PORTB1)
// set output to GND, red LED on
#define LEDON PORTB&=~(1<<PORTB1)
// to test the state of the LED
#define LEDISOFF PORTB&(1<<PORTB1)


// global packet buffer
#define BUFFER_SIZE 550
static uint8_t buf[BUFFER_SIZE+1];

// retransmit packet buffer
static uint8_t rtx_buf[BUFFER_SIZE+1];

//The Maximum Segment Size to use for transmission. This should never be larger than the MTU to avoid fragmentation.
#define MSS 2
#define MSS_H MSS >> 8
#define MSS_L MSS & 0xff

#if MSS > BUFFER_SIZE
	#error "The Maximum Segment Size cannot be larger than the receive buffer size"
#endif

//The initial window size. Note that the window can never be larger than the smaller between the receive buffer and the maximum segment size
#define WIN_SIZE MSS
#define WIN_SIZE_H WIN_SIZE >> 8
#define WIN_SIZE_L WIN_SIZE & 0xff

#if WIN_SIZE > MSS
	#error "The receive window size cannot be larger than the MSS"
#endif

//Calculates the position of the first tcp user data byte in the received pakcet buffer
#define TCP_DATA_START ((uint16_t)TCP_SRC_PORT_H_P+(buf[TCP_HEADER_LEN_P]>>4)*4)

//The maximum allowed incoming connections
#define MAX_CONNS 2

//static uint32_t seqnum = 0;

uint8_t mymac[6] = {0x54,0x55,0x58,0x10,0x00,0x29}; //MAC
uint8_t myip[4] = {192,168,95,3};	//IP
uint8_t netmask[4] = {255,255,255,0};	//NETMASK
	
#define LISTEN_PORT 23 //Listen port, telnet
#define PORT_H LISTEN_PORT >> 8
#define PORT_L LISTEN_PORT & 0xff

uint16_t dat_p;
uint16_t recv_len;

uint8_t seq_to_rcv[4]; /* The sequence number that we expect to receive next. */
uint8_t seq_last_sent[4]; /* The sequence number that was last sent by us. */
uint8_t seq_to_ack_nxt[4]; /* The sequence number that should be ACKed by next ACK from peer. */

uint8_t tcp_current_state;
uint16_t tcp_data_len = 0;
uint16_t plen;
uint16_t last_data_pos = 0;

uint8_t iss[4];

typedef struct _nip_conn 
{
	uint8_t tcp_current_state; //The state of the connection
	uint8_t local_port[2]; //Local port to listen on
	uint8_t remote_port[2]; //Remote port
	uint8_t remote_ipaddr[4]; //The IP address of the remote endpoint
	uint8_t seq_to_rcv[4]; /* The sequence number that we expect to receive next. */
	uint8_t seq_last_sent[4]; /* The sequence number that was last sent by us. */
	uint8_t seq_to_ack_nxt[4]; /* The sequence number that should be ACKed by next ACK from peer. */
} nip_conn;

nip_conn nip_conns[MAX_CONNS];

#ifdef _8_BIT_TIMER_RESOLUTION
	uint8_t timer_ticks = 0;
#else 
	#ifdef _16_BIT_TIMER_RESOLUTION
		uint16_t timer_ticks = 0;
	#else
		#ifdef _32_BIT_TIMER_RESOLUTION
			uint32_t timer_ticks = 0;
		#else
			#error "You must define a correct timer resolution, valid values are 8, 16 or 32 bits."
		#endif
	#endif
#endif

#ifdef FULL_WINDOW_SIZE
	uint16_t current_win_size = WIN_SIZE;
#else
	#if WIN_SIZE > 255
		#error "A smaller (8 bit) window size cannot exceed 255"
	#else
	uint8_t current_win_size = WIN_SIZE;	
	#endif
#endif

#define TCP_DATA_START ((uint16_t)TCP_SRC_PORT_H_P+(buf[TCP_HEADER_LEN_P]>>4)*4)

int main(void)
{
	tcp_current_state = TCP_STATE_CLOSED; //We begin in closed state
	
	DDRD = 0b11111111; //Initialize PORTD to output
	// set the clock speed to 8MHz
	// set the clock prescaler. First write CLKPCE to enable setting of clock the
	// next four instructions.
	CLKPR=(1<<CLKPCE);
	CLKPR=0; // 8 MHZ
	_delay_loop_1(0); // 60us
	DDRB|= (1<<DDB1); // LED, enable PB1, LED as output
	LEDOFF;
	
	//initialize the hardware driver for the enc28j60
	enc28j60Init(mymac);
	enc28j60clkout(2); // change clkout from 6.25MHz to 12.5MHz
	_delay_loop_1(0); // 60us
	enc28j60PhyWrite(PHLCON, 0x476);
	
	//Configure the port numbers for the connection slots. In this case we accept two connections to the Telnet port.
	nip_conns[0].local_port[0] = 23;
	nip_conns[1].local_port[0] = 23;
	listen(); //Places the sockets in listening mode
	
	while (1)
	{
		nip_tick();
	}
}

void make_eth(uint8_t *buf)
{
	uint8_t i = 0;
	//copy the destination mac from the source and fill my mac into src
	while(i < 6)
	{
		buf[ETH_DST_MAC + i] = buf[ETH_SRC_MAC +i];
		buf[ETH_SRC_MAC + i] = mymac[i];
		i++;
	}
}

void send_arp_reply(uint8_t *buf)
{
	uint8_t i = 0;
	buf[ETH_ARP_OPCODE_H_P] = ETH_ARP_OPCODE_REPLY_H_V;
	buf[ETH_ARP_OPCODE_L_P] = ETH_ARP_OPCODE_REPLY_L_V;
	// fill the mac addresses:
	do
	{
		buf[ETH_ARP_DST_MAC_P + i] = buf[ETH_ARP_SRC_MAC_P + i];
		buf[ETH_ARP_SRC_MAC_P + i] = mymac[i];
		i++;
	} while (i < 6); //I have issues when doing this like the one below
	i = 3;
	do
	{
		buf[ETH_ARP_DST_IP_P + i] = buf[ETH_ARP_SRC_IP_P + i];
		buf[ETH_ARP_SRC_IP_P + i] = myip[i];
		i--;
	} while (i);
	
	// eth+arp is 42 bytes:
	enc28j60PacketSend(42, buf);
}

// make a return ip header from a received ip packet
void make_ip(uint8_t *buf)
{
	uint8_t i = 3;
	do 
	{
		buf[IP_DST_P + i] = buf[IP_SRC_P + i];
		buf[IP_SRC_P + i] = myip[i];
		i--;
	} while (i);
	
	//fill_ip_hdr_checksum(buf); //When answering an echo request this not need be called since we exchange src and dst ip and the checksum is conmutative, only need to update the checksum.
}

void send_echo_reply(uint8_t *buf, uint16_t len)
{
	buf[ICMP_TYPE_P] = ICMP_TYPE_ECHOREPLY_V;
	
	// we changed only the icmp.type field from request(=8) to reply(=0).
	// we can therefore easily correct the checksum:
	if (buf[ICMP_CHECKSUM_P] > (0xff-0x08))
	{
		buf[ICMP_CHECKSUM_P+1]++;
	}
	buf[ICMP_CHECKSUM_P]+=0x08;
	//
	enc28j60PacketSend(len, buf);
}

void fill_ip_hdr_checksum(uint8_t *buf)
{
	uint16_t ck;
	// clear the 2 byte checksum
	buf[IP_CHECKSUM_P]=0;
	buf[IP_CHECKSUM_P+1]=0;
	buf[IP_FLAGS_P]=0x40; // don't fragment
	buf[IP_FLAGS_P+1]=0;  // fragement offset
	buf[IP_TTL_P]=64; // ttl
	// calculate the checksum:
	checksum(&buf[IP_P], IP_HEADER_LEN,0, &ck);
	buf[IP_CHECKSUM_P]=ck>>8;
	buf[IP_CHECKSUM_P+1]=ck& 0xff;
}

void checksum(uint8_t *buf, uint16_t len, uint8_t type, uint16_t *chk)
{
	// type 0=ip , icmp
	//      1=udp
	//      2=tcp
	uint32_t sum = 0;

	if (type != 0)
	{
		sum += type + len - 8;
	}
	
	// build the sum of 16bit words
	while(len >1){
		sum += (((uint32_t)*buf<<8)|*(buf+1));
		buf+=2;
		len-=2;
	}
	// if there is a byte left then add it (padded with zero)
	if (len){
		sum += (uint8_t)*buf;
	}
	// now calculate the sum over the bytes in the sum
	// until the result is only 16bit long
	while (sum>>16){
		sum = (sum & 0xFFFF)+(sum >> 16);
	}
	// build 1's complement:
	*chk =  ~sum;
}

inline void prepare_synack(uint8_t *buf)
{
	// put an inital seq number
	/*buf[TCP_SEQ_H_P] = 0;
	buf[TCP_SEQ_H_P + 1] = 0;
	buf[TCP_SEQ_H_P + 2] = 0;
	buf[TCP_SEQ_H_P + 3] = 0;*/
	//seqnum = 0;
	
	// add an mss options field with
	buf[TCP_OPTIONS_P]=2;
	buf[TCP_OPTIONS_P+1]=4;
	buf[TCP_OPTIONS_P+2] = MSS_H;
	buf[TCP_OPTIONS_P+3]=MSS_L;
	// The tcp header length is only a 4 bit field (the upper 4 bits).
	// It is calculated in units of 4 bytes.
	// E.g 24 bytes: 24/4=6 => 0x60=header len field
	buf[TCP_HEADER_LEN_P]=0x60;
}

// Make just an ack packet with no tcp data inside
// This will modify the eth/ip/tcp header
// datlentoack minimum value is 1, values below 1 produce erroneous behavior
void send_tcp_ack(uint8_t *buf,int16_t datlentoack, uint8_t addflags, uint8_t extra_len)
{
	uint16_t ck;
	// total length field in the IP header must be set:
	// 20 bytes IP + 20 bytes tcp (when no options)
	buf[IP_TOTLEN_L_P] = 40 + extra_len;
	fill_ip_hdr_checksum(buf);
	// fill the header:
	buf[TCP_FLAGS_P]=TCP_FLAGS_ACK_V | addflags;
	
	#ifdef FULL_WINDOW_SIZE
	buf[TCP_WIN_SIZE] = current_win_size >> 8;
	buf[TCP_WIN_SIZE + 1] = current_win_size & 0xff;
	#else
	buf[TCP_WIN_SIZE]= 0;
	buf[TCP_WIN_SIZE+1]= current_win_size;
	#endif
	
	// calculate the checksum, len=8 (start from ip.src) + TCP_HEADER_LEN_PLAIN + data len
	checksum(&buf[IP_SRC_P], 8+TCP_HEADER_LEN_PLAIN + extra_len, IP_PROTO_TCP_V, &ck);
	buf[TCP_CHECKSUM_H_P] = ck >> 8;
	buf[TCP_CHECKSUM_L_P] = ck & 0xff;
	enc28j60PacketSend(IP_HEADER_LEN+TCP_HEADER_LEN_PLAIN + extra_len +ETH_HEADER_LEN,buf);
}

void send_tcp_arbitrary(uint8_t *buf,int16_t datlentoack, uint8_t flags, uint8_t extra_len)
{
	uint16_t ck;
	// total length field in the IP header must be set:
	// 20 bytes IP + 20 bytes tcp (when no options)
	buf[IP_TOTLEN_L_P] = 40 + extra_len;
	fill_ip_hdr_checksum(buf);
	// fill the header:
	buf[TCP_FLAGS_P]=flags;
	
	// calculate the checksum, len=8 (start from ip.src) + TCP_HEADER_LEN_PLAIN + data len
	checksum(&buf[IP_SRC_P], 8+TCP_HEADER_LEN_PLAIN + extra_len, IP_PROTO_TCP_V, &ck);
	buf[TCP_CHECKSUM_H_P] = ck >> 8;
	buf[TCP_CHECKSUM_L_P] = ck & 0xff;
	enc28j60PacketSend(IP_HEADER_LEN+TCP_HEADER_LEN_PLAIN + extra_len +ETH_HEADER_LEN,buf);
}

// make a return tcp header from a received tcp packet
// rel_ack_num is how much we must step the seq number received from the
// other side. We do not send more than 765 bytes of text (=data) in the tcp packet.
// No mss is included here.
//
// After calling this function you can fill in the first data byte at TCP_OPTIONS_P+4
// If cp_seq=0 then an initial sequence number is used (should be use in synack)
// otherwise it is copied from the packet we received
void make_tcphead(uint8_t *buf,uint16_t rel_ack_num/*,uint8_t cp_seq*/)
{
	uint8_t i;
	// copy ports:
	i=buf[TCP_DST_PORT_H_P];
	buf[TCP_DST_PORT_H_P]=buf[TCP_SRC_PORT_H_P];
	buf[TCP_SRC_PORT_H_P]=i;
	//
	i=buf[TCP_DST_PORT_L_P];
	buf[TCP_DST_PORT_L_P]=buf[TCP_SRC_PORT_L_P];
	buf[TCP_SRC_PORT_L_P]=i;
	step_seq(buf, rel_ack_num/*, 1*/);
	
	// zero the checksum
	buf[TCP_CHECKSUM_H_P]=0;
	buf[TCP_CHECKSUM_L_P]=0;
	// no options:
	// 20 bytes:
	// The tcp header length is only a 4 bit field (the upper 4 bits).
	// It is calculated in units of 4 bytes.
	// E.g 20 bytes: 20/4=6 => 0x50=header len field
	buf[TCP_HEADER_LEN_P]=0x50;
}

void make_tcp_ack_with_data_noflags(uint8_t *buf,uint16_t dlen)
{
	uint16_t j;
	// total length field in the IP header must be set:
	// 20 bytes IP + 20 bytes tcp (when no options) + len of data
	j=IP_HEADER_LEN+TCP_HEADER_LEN_PLAIN+dlen;
	buf[IP_TOTLEN_H_P]=j>>8;
	buf[IP_TOTLEN_L_P]=j& 0xff;
	fill_ip_hdr_checksum(buf);
	// zero the checksum
	buf[TCP_CHECKSUM_H_P]=0;
	buf[TCP_CHECKSUM_L_P]=0;
	// calculate the checksum, len=8 (start from ip.src) + TCP_HEADER_LEN_PLAIN + data len
	checksum(&buf[IP_SRC_P], 8+TCP_HEADER_LEN_PLAIN+dlen,2, &j);
	buf[TCP_CHECKSUM_H_P]=j>>8;
	buf[TCP_CHECKSUM_L_P]=j& 0xff;
	
	//Copy the data for possible retransmit due to timeout
	ready_rtx_data();
	
	//Send the data
	enc28j60PacketSend(IP_HEADER_LEN+TCP_HEADER_LEN_PLAIN+dlen+ETH_HEADER_LEN,buf);
}

// swap seq and ack number and count ack number up
inline void step_seq(uint8_t *buf,uint16_t rel_ack_num/*,uint8_t cp_seq*/)
{
	uint8_t i = 4;
	// sequence numbers:
	// add the rel ack num to SEQACK
	while(i>0){
		i--;
		rel_ack_num=buf[TCP_SEQ_H_P + i]+rel_ack_num;
		buf[TCP_SEQ_H_P + i]=buf[TCP_SEQACK_H_P + i];
		buf[TCP_SEQACK_H_P + i]=/*0xff&*/rel_ack_num;
		rel_ack_num=rel_ack_num>>8;
		seq_to_rcv[i] = buf[TCP_SEQACK_H_P + i];
		seq_last_sent[i] = buf[TCP_SEQ_H_P + i];
	}
}

//Maybe not needed
void increase_seq_num()
{
	if(++iss[3] == 0) {
		if(++iss[2] == 0) {
			if(++iss[1] == 0) {
				++iss[0];
			}
		}
	}
	buf[TCP_SEQ_H_P+0] = iss[0];
	buf[TCP_SEQ_H_P+1] = iss[1];
	buf[TCP_SEQ_H_P+2] = iss[2];
	buf[TCP_SEQ_H_P+3] = iss[3];
}

// do some basic length calculations
inline void get_tcp_data_len(uint8_t *buf)
{
	uint16_t i = buf[IP_TOTLEN_H_P] << 8 | buf[IP_TOTLEN_L_P];
	tcp_data_len = i - (buf[TCP_HEADER_LEN_P] >> 4) * 4 - IP_HEADER_LEN;
}

void add_tcp_data_byte(uint16_t *pos, const uint8_t data_byte) //Esta es mia
{
	// fill in tcp data at position pos
	// with no options the data starts after the checksum + 2 more bytes (urgent ptr)
	buf[TCP_CHECKSUM_L_P + 3 + *pos] = data_byte;
	
	*pos++;
}

// fill a binary string of len data into the tcp packet
void fill_tcp_data(uint16_t *pos, const uint8_t *buffer, uint8_t len)
{
	// fill in tcp data at position pos
	//
	// with no options the data starts after the checksum + 2 more bytes (urgent ptr)
	while (len) {
		buf[TCP_CHECKSUM_L_P+  3 + *pos] = *buffer;
		pos++;
		buffer++;
		len--;
	}
}

void timer200()
{
	_delay_ms(200);
	timer_ticks++;
}

void wait_for(uint8_t secs)
{
	uint8_t times = secs * 5;
	
	while (times > 0)
	{
		timer200();
		times--;
	}
}

void ready_rtx_data()
{
	uint8_t i = 0;
	while (i < last_data_pos)
	{
		rtx_buf[i] = buf[i];
	}
}


//Performs a cycle of processing of the network stack
void nip_tick()
{
	plen = enc28j60PacketReceive(BUFFER_SIZE, buf);
	if (plen > 0)
	{
		#ifndef EXT_PACKET_FILTER
		//Check here if the packet is meant for the host
		#endif
		
		make_eth(buf);
		
		if (buf[MY_ETH_TYPE_L_P] == 0x06)
		{
			//Is ARP
			send_arp_reply(buf);
		}
		else if (buf[MY_ETH_TYPE_L_P] == 0)
		{
			//Is an IP datagram
			make_ip(buf);
			
			if (buf[IP_PROTO_P] == IP_PROTO_TCP_V)
			{
				/* Demultiplex this segment. */
				/* First check any active connections. */
				for (int i = 0; i < MAX_CONNS; i++)
				{
					if (nip_conns[i].tcp_current_state != TCP_STATE_CLOSED)
					{
						if (
					}
				}
				
				
				if (buf[TCP_FLAGS_P] == TCP_FLAGS_SYN_V)
				{
					//Connection request, an active open from the client. Send SYN-ACK
					// Put an inital seq number. Note that we put it in the ACK number, that's because the ACK and the SEQ number are swapped inside make_tcphead()
					buf[TCP_SEQACK_H_P] = 0;
					buf[TCP_SEQACK_H_P + 1] = 0;
					buf[TCP_SEQACK_H_P + 2] = 0;
					buf[TCP_SEQACK_H_P + 3] = 0;
					make_tcphead(buf,1/*,0*/); // no options
					
					//Check if we still have capacity for another connection and if it's meant for any listening port.
					//IMPORTANT: We use src port instead of dst port because make_tcphead() swaps them, so now src port actually is the port of the one sending us the packet.
					if (buf[TCP_SRC_PORT_H_P] != PORT_H || buf[TCP_SRC_PORT_L_P] != PORT_L)
					{
						//Connection attempt not addressed to any listening port. Send RST packet
						buf[TCP_WIN_SIZE] = 0;
						buf[TCP_WIN_SIZE+1] = 0;
						send_tcp_arbitrary(buf, 1, TCP_FLAGS_RST_V | TCP_FLAGS_ACK_V, 0);
						return;
					}
					
					tcp_current_state = TCP_STATE_SYN_RCVD;
					prepare_synack(buf);
					send_tcp_ack(buf, 1, TCP_FLAGS_SYN_V, 4); //extra_len = 4 because of the tcp option of MSS
				}
				else if (buf[TCP_FLAGS_P] & TCP_FLAGS_FIN_V && tcp_current_state == TCP_STATE_ESTABLISHED) // A FIN is only valid in the Established state
				{
					//Client performing an half close
					make_tcphead(buf,1/*,0*/); // no options
					send_tcp_ack(buf, 1, 0, 0);
					tcp_current_state = TCP_STATE_CLOSE_WAIT;
					
					send_tcp_ack(buf, 1, TCP_FLAGS_FIN_V, 0);
					tcp_current_state = TCP_STATE_LAST_ACK;
					
				}
				else if (buf[TCP_FLAGS_P] & TCP_FLAGS_RST_V)
				{
					
				}
				else
				{
					//It's either an URG or PSH or ACK piggybacked packet possibly with data
					
					//ACK and SEQ checks. OPTIMIZE THIS
					uint32_t seq_last_sent32 = (uint32_t)(seq_last_sent[0] << 24) + (uint32_t)(seq_last_sent[1] << 16) + (uint32_t)(seq_last_sent[2] << 8) + (uint32_t)(seq_last_sent[0] << 0);
					uint32_t seq_rcvd32 = (uint32_t)(buf[TCP_SEQ_H_P] << 24) + (uint32_t)(buf[TCP_SEQ_H_P+1] << 16) + (uint32_t)(buf[TCP_SEQ_H_P+2] << 8) + (uint32_t)(buf[TCP_SEQ_H_P+3] << 0);
					uint32_t seq_to_rcv32 = (uint32_t)(seq_to_rcv[0] << 24) + (uint32_t)(seq_to_rcv[1] << 16) + (uint32_t)(seq_to_rcv[2] << 8) + (uint32_t)(seq_to_rcv[0] << 0);
					uint32_t rcv_ack32 = (uint32_t)(buf[TCP_SEQACK_H_P] << 24) + (uint32_t)(buf[TCP_SEQACK_H_P+1] << 16) + (uint32_t)(buf[TCP_SEQACK_H_P+2] << 8) + (uint32_t)(buf[TCP_SEQACK_H_P+3] << 0);
					
					if (seq_last_sent32 != rcv_ack32 - 1 && seq_to_rcv32 != seq_rcvd32)
					{
						//Wrong SEQ and/or ACK. Silently discard or perhaps resend SYN-ACK
						//TODO Code the resending of SYN-ACK
						return;
					}
					
					if (tcp_current_state == TCP_STATE_SYN_RCVD && buf[TCP_FLAGS_P] & TCP_FLAGS_ACK_V)
					{
						//Received the ack finishing the 3 way handshake.
						
						tcp_current_state = TCP_STATE_ESTABLISHED;
						return;
					}
					else if (tcp_current_state == TCP_STATE_LAST_ACK && buf[TCP_FLAGS_P] & TCP_FLAGS_ACK_V)
					{
						tcp_current_state = TCP_STATE_CLOSED;
						return;
					}
					get_tcp_data_len(buf);
					if (tcp_data_len > 0 && tcp_current_state == TCP_STATE_ESTABLISHED) //Received data is only valid in the Established state, otherwise silently discard
					{
						last_data_pos = 0; //Automatically reset the last_data_pos marker
						if (current_win_size > 0)
						{
							make_tcphead(buf, tcp_data_len);
							//current_win_size -= tcp_data_len; //ENABLE THIS
							//send_tcp_ack(buf, tcp_data_len, 0, 0);
							
							//increase_seq_num(); PUEDE QUE NO HAGA FALTA
							uint8_t recv_data = buf[TCP_DATA_START];
							add_tcp_data_byte(&last_data_pos, recv_data); //ECHO the received data
							//fill_tcp_data(&last_data_pos, &recv_data, 1); //Example of use
							
							make_tcp_ack_with_data_noflags(buf, 1);
							wait_for(50); //Wait for data to arrive
							//Check if an ACK for my data arrived, otherwise resend the data
						}
						else
						{
							//Send zero window message
							make_tcphead(buf, 0);
							send_tcp_ack(buf, 0, 0, 0);
						}
					}
					else if (tcp_current_state == TCP_STATE_ESTABLISHED)
					{
						//Just an ACK with no data
						//Cancel and reset retransmission timer if the ACK and SEQ numbers are ok for my last data sent
						
					}
				}
			}
			#ifdef PROCESS_PING
			else if (buf[IP_PROTO_P] == IP_PROTO_ICMP_V && buf[ICMP_TYPE_P] == ICMP_TYPE_ECHOREQUEST_V)
			{
				// a ping packet, let's send pong
				send_echo_reply(buf, plen);
			}
			#endif
		}
		else if (buf[MY_ETH_TYPE_L_P] == 0x35)
		{
			//Is RARP
		}
	}
}

void listen()
{
	for (int i = 0; i < MAX_CONNS; ++i)
	{
		nip_conns[i].tcp_current_state = TCP_STATE_LISTEN;
	}
}

void send()
{
	//NOTE: Sending data is only valid in the ESTABLISHED state for TCP connections.
	
	
	
}

