/*
 * nIPConfig.h
 *
 * Created: 19/07/2019 4:19:45:PM
 *  Author: Usuario1
 */ 


#ifndef NIPCONFIG_H_
#define NIPCONFIG_H_

#define PROCESS_PING

#define ARP
#define RARP

#undef URGENT
#undef OPTIONS
#undef TOS

#define EXT_CHECKSUM_CALC //Checksums verified by hardware ic of ethernet
#undef EXT_PACKET_FILTER //The ethernet hardware receives only packets meant for the host
#undef DELAYED_ACK //Implements delayed acks
#undef NAGLE_ALGORITHM
#undef SIMPLE_RETRANSMISSION
#define KARN_ALGORITHM
#define JACOBSON_STANDARD_RETRANSMISSION
#undef FLOATING_POINT_MEASURES
#define INTEGER_MEASURES
#undef SLOW_START
#undef CONGESTION_AVOIDANCE
#undef FAST_RETRANSMIT
#undef FAST_RECOVERY
#undef EXPONENTIAL_BACKOFF_RETRANSMISSION
#undef FULL_WINDOW_SIZE

#undef _32_BIT_TIMER_RESOLUTION
#define _16_BIT_TIMER_RESOLUTION
#undef _8_BIT_TIMER_RESOLUTION

#define NIP_RTO 3

#endif /* NIPCONFIG_H_ */