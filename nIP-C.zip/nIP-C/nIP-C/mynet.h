/*
 * mynet.h
 *
 * Created: 22/07/2019 6:09:44:PM
 *  Author: Usuario1
 */ 


#ifndef MYNET_H_
#define MYNET_H_

#define MY_ETH_TYPE_L_P 13



#endif /* MYNET_H_ */